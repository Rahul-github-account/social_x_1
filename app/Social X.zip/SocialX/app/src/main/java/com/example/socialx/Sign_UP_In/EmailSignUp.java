package com.example.socialx.Sign_UP_In;

public class EmailSignUp {
}
